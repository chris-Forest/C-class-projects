#include <stdio.h>
#include <stdlib.h>

int main() {
	int ID[] = { 3,7,8,12,13,14,18,20,23,24,27,29,32,33,34,36,39,40,44,49};
	char fNames[][20] = { "Johny","Andrea","Amelia","Jasmine","Anders","Roberto",
					   "Angelina", "Sherlock","Michael","Marvin","Jenny",
					   "Olive","Amedie","Vanessa","Fenando","Sadio","Selena",
	                    "Romeo","Juliette","Charlie"};
	char lNames[][20] = {"Aladin","Torredo","Paradis","Marlon","Ronaldo",
	                    "Rodriguez","Farmer","Douglas","Stone","Oreo",
	                    "Bernouilli", "Archimedes","Watt","Curie", "Gamma",
	                    "Marbella","Danube","Santiego","Rochecoute","Madelon"};


}